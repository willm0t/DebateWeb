//handles the fading in and out of the login form & registration form



$(document).ready(function() {
    //on click of loginButton
  $('#loginButton').click(function() {
      $.ajax({
          url: '/login',
          type: 'GET',
          success: function(response) {
            //makes login from fade in
              $('#loginForm').html(response);
              $('#loginForm').fadeIn();
          },
          error: function(error) {
              console.log(error);
          }
      });
  });

  $(document).click(function(event) {
    //starts fade out when anywhere expect login form is clicked
      if (!$(event.target).closest('#loginForm').length && !$(event.target).is('#loginForm')) {
          $('#loginForm').fadeOut();
      }
  });
  //stops event from happening if click is within the login form
  $('#loginContents').click(function(event) {
      event.stopPropagation();
  });
});

//fade in & out for registration
$(document).ready(function() {
    $('#registerButton').click(function() {
        $.ajax({
            url: '/register',
            type: 'GET',
            success: function(response) {
                $('#registerForm').html(response);
                //built in jquery fadein
                $('#registerForm').fadeIn();
            },
            error: function(error) {
                console.log(error);
            }
        });
    });
  
    $(document).click(function(event) {
        if (!$(event.target).closest('#registerForm').length && !$(event.target).is('#registerForm')) {
            $('#registerForm').fadeOut();
        }
    });
  
    $('#registerContents').click(function(event) {
        event.stopPropagation();
    });
});
