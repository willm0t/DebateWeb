BEGIN TRANSACTION;
CREATE TABLE claim (
    claimID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,   -- CLaim ID number
    topic INTEGER NOT NULL REFERENCES topic(topicID) ON DELETE CASCADE ON UPDATE CASCADE, -- FK of claim
    postingUser INTEGER REFERENCES user(userID) ON DELETE SET NULL ON UPDATE CASCADE, -- FK of poisting user
    creationTime INTEGER NOT NULL,                       -- Time topic was created
    updateTime INTEGER NOT NULL,                         -- Last time a reply was added
    text TEXT NOT NULL                                   -- Actual text
);
INSERT INTO "claim" VALUES(6,5,'admin',1683323045,1683323045,'Messi');
INSERT INTO "claim" VALUES(7,6,'admin',1683323188,1683323188,'Martinelli is 100 times worse');
CREATE TABLE claimToClaim (
    claimRelID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,                        -- Claim relationship ID
    first INTEGER NOT NULL REFERENCES claim(claimID) ON DELETE CASCADE ON UPDATE CASCADE, -- FK of first related claim
    second INTEGER NOT NULL REFERENCES claim(claimID) ON DELETE CASCADE ON UPDATE CASCADE, -- FK of second related claim
    claimRelType INTEGER NOT NULL REFERENCES claimToClaimType(claimRelTypeID) ON DELETE CASCADE ON UPDATE CASCADE,
                                                                                            -- FK of type of relation
    /* Specify that there can't be several relationships between the same pair of two claims */
    CONSTRAINT claimToClaimUnique UNIQUE (first, second)
);
CREATE TABLE claimToClaimType (
    claimRelTypeID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    claimRelType TEXT NOT NULL
);
INSERT INTO "claimToClaimType" VALUES(1,'Opposed');
INSERT INTO "claimToClaimType" VALUES(2,'Equivalent');
CREATE TABLE replyText (
    replyTextID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,                           -- Reply ID
    postingUser INTEGER REFERENCES user(userID) ON DELETE SET NULL ON UPDATE CASCADE, -- FK of posting user
    creationTime INTEGER NOT NULL,                                                    -- Posting time
    text TEXT NOT NULL                                                                -- Text of reply
);
INSERT INTO "replyText" VALUES(5,'admin',1683323061,'Messi is mid compared to Ronaldo');
INSERT INTO "replyText" VALUES(6,'admin',1683323204,'when I say 100, I mean it');
CREATE TABLE replyToClaim (
    replyToClaimID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,                                       -- Relationship ID
    reply INTEGER NOT NULL REFERENCES replyText (replyTextID) ON DELETE CASCADE ON UPDATE CASCADE,   -- FK of related reply
    claim INTEGER NOT NULL REFERENCES claim (claimID) ON DELETE CASCADE ON UPDATE CASCADE,           -- FK of related claim
    replyToClaimRelType INTEGER NOT NULL REFERENCES replyToClaimType(claimReplyTypeID) ON DELETE CASCADE ON UPDATE CASCADE -- FK of relation type
);
INSERT INTO "replyToClaim" VALUES(5,5,6,'Counterargument');
INSERT INTO "replyToClaim" VALUES(6,6,7,'Clarification');
CREATE TABLE replyToClaimType (
    claimReplyTypeID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    claimReplyType TEXT NOT NULL
);
INSERT INTO "replyToClaimType" VALUES(1,'Clarification');
INSERT INTO "replyToClaimType" VALUES(2,'Supporting Argument');
INSERT INTO "replyToClaimType" VALUES(3,'Counterargument');
CREATE TABLE replyToReply (
    replyToReplyID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,                                         -- Relationship ID
    reply INTEGER NOT NULL REFERENCES replyText(replyTextID) ON DELETE CASCADE ON UPDATE CASCADE,
    parent INTEGER NOT NULL REFERENCES replyText(replyTextID) ON DELETE CASCADE ON UPDATE CASCADE,
    replyToReplyRelType INTEGER NOT NULL REFERENCES replyToReplyType(replyReplyTypeID) ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE replyToReplyType (
    replyReplyTypeID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    replyReplyType TEXT NOT NULL
);
INSERT INTO "replyToReplyType" VALUES(1,'Evidence');
INSERT INTO "replyToReplyType" VALUES(2,'Support');
INSERT INTO "replyToReplyType" VALUES(3,'Rebuttal');
CREATE TABLE topic (
    topicID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,  -- Topic's ID number
    topicName TEXT NOT NULL,                             -- Topic's text
    postingUser INTEGER REFERENCES user(userID) ON DELETE SET NULL ON UPDATE CASCADE, -- FK (foreign key) of posting user
    creationTime INTEGER NOT NULL,                       -- Time topic was created
    updateTime INTEGER NOT NULL                          -- Last time a claim/reply was added
);
INSERT INTO "topic" VALUES(5,'Ronaldo or Messi?','admin',1683323033,1683323033);
INSERT INTO "topic" VALUES(6,'Rashford is the best player in the league','admin',1683323161,1683323161);
CREATE TABLE user (
    userID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, -- Integer user ID / key
    userName TEXT NOT NULL,                            -- Login username
    passwordHash BLOB NOT NULL,                        -- Hashed password (bytes in python)
    isAdmin BOOLEAN NOT NULL,                          -- If user is admin or not. Ignore if not implementing admin
    creationTime INTEGER NOT NULL,                     -- Time user was created
    lastVisit INTEGER NOT NULL                         -- User's last visit, for showing new content when they return
);
INSERT INTO "user" VALUES(7,'admin',X'32783CEF30BC23D9549623AA48AA8556346D78BD3CA604F277D63D6E573E8CE0',0,0,0);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('claimToClaimType',2);
INSERT INTO "sqlite_sequence" VALUES('replyToClaimType',3);
INSERT INTO "sqlite_sequence" VALUES('replyToReplyType',3);
INSERT INTO "sqlite_sequence" VALUES('topic',6);
INSERT INTO "sqlite_sequence" VALUES('user',20);
INSERT INTO "sqlite_sequence" VALUES('claim',7);
INSERT INTO "sqlite_sequence" VALUES('replyText',6);
INSERT INTO "sqlite_sequence" VALUES('replyToClaim',6);
COMMIT;
