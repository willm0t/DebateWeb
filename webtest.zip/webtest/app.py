import sqlite3, hashlib
from datetime import datetime
import time

from flask import Flask, render_template, jsonify, request, session, redirect, url_for

app = Flask(__name__)
app.secret_key = 'backdoor'

# deprecated and being removed but i could not work out a solution to clear the session info without it
@app.before_first_request
def setup():
    session.pop('username', None)


@app.route('/')
def main():  # main page
    # connects to database using sqlite3
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    # selects all topic names in the topic table and stores them
    c.execute('SELECT topicName FROM topic')
    topics = c.fetchall()

    conn.close()
    # renders template and sends topics & session details
    return render_template('main.html', topics=topics, session=session)


@app.route('/topic/<string:topic_name>', methods=['GET', 'POST'])
def topicPage(topic_name): #topic Page
    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    #fetches info about topic, for use in claims query
    c.execute('SELECT topicName, topicID FROM topic WHERE topicName = ?', (topic_name,))
    result = c.fetchone()
    topic = result[0]
    topicID = result[1]

    c.execute('SELECT * FROM claim WHERE topic = ?', (topicID,))
    claims = c.fetchall()

    conn.close()
    return render_template('topic.html', claims=claims, topic=topic)


@app.route('/claimPage/<string:claimID>', methods=['GET', 'POST'])
def claimPage(claimID): # claim page
    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    #fetches all data from claim record with matching claimID
    c.execute('SELECT * FROM claim WHERE claimID = ?', (claimID,))
    claim = list(c.fetchone())

    # fetches data from 2 tables
    c.execute(
        'SELECT replyText.replyTextID, replyText.text, replyToClaim.replyToClaimRelType, replyText.postingUser, replyText.creationTime '
        'FROM replyText '
        'JOIN replyToClaim ON replyText.replyTextID = replyToClaim.reply '
        'WHERE replyToClaim.claim = ?',
        (claimID,))

    claim_replies = c.fetchall()

    conn.close()
    return render_template('claim.html', claim=claim, claim_replies=claim_replies)


#user actions

@app.route('/addTopic', methods=['GET', 'POST'])
def addTopic(): #adding a topic to database
    #saves all necessary data to variables
    topicName = request.json['topic']
    postingUser = session['username']
    creationTime = int(time.time())
    updateTime = int(time.time())

    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    c.execute('INSERT INTO topic (topicName, postingUser, creationTime, updateTime) VALUES (?, ?, ?, ?)',
              (topicName, postingUser, creationTime, updateTime))

    conn.commit()
    conn.close()
    # redirects to root
    return redirect('/')


@app.route('/addClaim', methods=['GET', 'POST'])
def addClaim(): # adding claim to database
    claim = request.json['body']
    topic_name = request.json['topic_name']
    postingUser = session['username']
    creationTime = int(time.time())
    print(creationTime)
    updateTime = int(time.time())

    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    c.execute('SELECT topicID FROM topic WHERE topicName = ?', (topic_name,))
    topicID = c.fetchone()[0]
    print(topicID)

    c.execute('INSERT INTO claim (topic, postingUser, creationTime, updateTime, text) VALUES (?, ?, ?, ?, ?)', (topicID, postingUser, creationTime, updateTime, claim))
    conn.commit()
    conn.close()
    return redirect(url_for('topicPage', topic_name=topic_name))


@app.route('/addReply', methods=['POST'])
def addReply():
    print("replying...")
    reply = request.json['reply']
    replyType = request.json['type']
    claimID = request.json['claim_id']
    postingUser = session['username']
    creation_time = int(time.time())
    print(reply)

    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    c.execute('INSERT INTO replyText (postingUser, creationTime, text) VALUES (?, ?, ?)',
              (postingUser, creation_time, reply))
    replyID = c.lastrowid

    c.execute('INSERT INTO replyToClaim (reply, claim, replyToClaimRelType) VALUES (?, ?, ?)',
              (replyID, claimID, replyType))
    conn.commit()
    conn.close()

    return redirect(url_for('claimPage', claim_name=claimID))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.json['username']
        password = request.json['password']

        conn = sqlite3.connect("database.db")
        c = conn.cursor()
        c.execute("SELECT passwordHash FROM user WHERE userName = ?", (username,))
        row = c.fetchone()
        if row is None:
            conn.close()
            return jsonify({'error': 'Invalid username or password'}), 401

        passwordHash = row[0]
        inputPasswordHash = hashlib.sha256(password.encode()).digest()
        if passwordHash != inputPasswordHash:
            conn.close()
            return jsonify({'error': 'Invalid username or password'}), 401

        session['username'] = username

        conn.close()
        return jsonify({'message': 'Login Successful'}), 200
    return render_template('login_form.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':

        username = request.json['username']
        password = request.json['password']
        passwordHash = hashlib.sha256(password.encode()).digest()

        conn = sqlite3.connect("database.db")
        c = conn.cursor()
        c.execute("INSERT INTO user (userName, passwordHash, isAdmin, creationTime, lastVisit) VALUES (?, ?, ?, ?, ?)", (username, passwordHash, False, 0, 0))
        conn.commit()
        conn.close()

        return "User registered successfully"
    return render_template('register_form.html')


@app.route('/logout', methods=['GET'])
def logout():
    session.clear()
    return redirect('/')



if __name__ == '__main__':
    app.run()
